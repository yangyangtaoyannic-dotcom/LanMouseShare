using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;

[assembly: AssemblyTitle("LanMouseShare.Agent")]
[assembly: AssemblyDescription("Interactive tray agent for LAN keyboard, mouse, clipboard, and file sharing.")]
[assembly: AssemblyCompany("LanMouseShare")]
[assembly: AssemblyProduct("LanMouseShare")]
[assembly: ComVisible(false)]
[assembly: Guid("c137c9e7-5e4c-4d40-b996-9c179321e947")]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: AssemblyVersion("0.1.42.0")]
[assembly: AssemblyFileVersion("0.1.42.0")]
