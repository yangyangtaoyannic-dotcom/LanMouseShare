using System;
using System.Runtime.InteropServices;
using LanMouseShare.Core.Protocol;

namespace LanMouseShare.Input
{
    public sealed class InputInjector
    {
        public void Inject(InputPayload payload)
        {
            if (payload == null)
            {
                return;
            }

            if (payload.Kind == InputKinds.Key)
            {
                InjectKey(payload);
            }
            else if (payload.Kind == InputKinds.MouseMove)
            {
                InjectMouseMove(payload.X, payload.Y);
            }
            else if (payload.Kind == InputKinds.MouseMoveRelative)
            {
                InjectMouseMoveRelative(payload.X, payload.Y);
            }
            else if (payload.Kind == InputKinds.MouseWheel)
            {
                InjectMouseWheel(payload.Delta);
            }
            else if (payload.Kind == InputKinds.MouseButton)
            {
                InjectMouseButton(payload.Button, payload.IsDown);
            }
        }

        public void ReleaseLeftMouseButton()
        {
            InjectMouseButton(NativeMethods.WM_LBUTTONUP, false);
        }

        public void ReleaseAllMouseButtons()
        {
            InjectMouseButton(NativeMethods.WM_LBUTTONUP, false);
            InjectMouseButton(NativeMethods.WM_RBUTTONUP, false);
            InjectMouseButton(NativeMethods.WM_MBUTTONUP, false);
        }

        private static void InjectKey(InputPayload payload)
        {
            var input = new NativeMethods.INPUT();
            input.type = NativeMethods.INPUT_KEYBOARD;
            if (payload.ScanCode > 0)
            {
                input.u.ki.wScan = (ushort)payload.ScanCode;
                input.u.ki.dwFlags = NativeMethods.KEYEVENTF_SCANCODE;
            }
            else
            {
                input.u.ki.wVk = (ushort)payload.VirtualKey;
            }

            if (payload.IsExtendedKey)
            {
                input.u.ki.dwFlags |= NativeMethods.KEYEVENTF_EXTENDEDKEY;
            }

            if (!payload.IsDown)
            {
                input.u.ki.dwFlags |= NativeMethods.KEYEVENTF_KEYUP;
            }

            Send(input);
        }

        private static void InjectMouseMove(int x, int y)
        {
            int width = Math.Max(1, NativeMethods.GetSystemMetrics(0) - 1);
            int height = Math.Max(1, NativeMethods.GetSystemMetrics(1) - 1);
            var input = new NativeMethods.INPUT();
            input.type = NativeMethods.INPUT_MOUSE;
            input.u.mi.dx = x * 65535 / width;
            input.u.mi.dy = y * 65535 / height;
            input.u.mi.dwFlags = NativeMethods.MOUSEEVENTF_MOVE | NativeMethods.MOUSEEVENTF_ABSOLUTE;
            Send(input);
        }

        private static void InjectMouseMoveRelative(int dx, int dy)
        {
            if (dx == 0 && dy == 0)
            {
                return;
            }

            var input = new NativeMethods.INPUT();
            input.type = NativeMethods.INPUT_MOUSE;
            input.u.mi.dx = dx;
            input.u.mi.dy = dy;
            input.u.mi.dwFlags = NativeMethods.MOUSEEVENTF_MOVE;
            Send(input);
        }

        private static void InjectMouseWheel(int delta)
        {
            var input = new NativeMethods.INPUT();
            input.type = NativeMethods.INPUT_MOUSE;
            input.u.mi.mouseData = unchecked((uint)delta);
            input.u.mi.dwFlags = NativeMethods.MOUSEEVENTF_WHEEL;
            Send(input);
        }

        private static void InjectMouseButton(int message, bool isDown)
        {
            uint flags = 0;
            if (message == NativeMethods.WM_LBUTTONDOWN || message == NativeMethods.WM_LBUTTONUP)
            {
                flags = isDown ? NativeMethods.MOUSEEVENTF_LEFTDOWN : NativeMethods.MOUSEEVENTF_LEFTUP;
            }
            else if (message == NativeMethods.WM_RBUTTONDOWN || message == NativeMethods.WM_RBUTTONUP)
            {
                flags = isDown ? NativeMethods.MOUSEEVENTF_RIGHTDOWN : NativeMethods.MOUSEEVENTF_RIGHTUP;
            }
            else if (message == NativeMethods.WM_MBUTTONDOWN || message == NativeMethods.WM_MBUTTONUP)
            {
                flags = isDown ? NativeMethods.MOUSEEVENTF_MIDDLEDOWN : NativeMethods.MOUSEEVENTF_MIDDLEUP;
            }

            if (flags != 0)
            {
                var input = new NativeMethods.INPUT();
                input.type = NativeMethods.INPUT_MOUSE;
                input.u.mi.dwFlags = flags;
                Send(input);
            }
        }

        private static void Send(NativeMethods.INPUT input)
        {
            var inputs = new[] { input };
            NativeMethods.SendInput(1, inputs, Marshal.SizeOf(typeof(NativeMethods.INPUT)));
        }
    }
}
