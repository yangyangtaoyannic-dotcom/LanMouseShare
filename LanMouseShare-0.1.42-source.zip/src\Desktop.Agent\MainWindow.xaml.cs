using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using LanMouseShare.Core.Configuration;
using LanMouseShare.Core.Control;
using LanMouseShare.Core.Diagnostics;
using LanMouseShare.Core.Ipc;
using LanMouseShare.Core.Protocol;
using LanMouseShare.Input;
using Microsoft.Win32;
using Forms = System.Windows.Forms;
using DrawingPoint = System.Drawing.Point;
using DrawingSize = System.Drawing.Size;

namespace LanMouseShare.Agent
{
    public partial class MainWindow : Window
    {
        private const string AppVersion = "0.1.42";
        private const int CornerBlockPixels = 80;
        private const string RunValueName = "LanMouseShare.Agent";

        private readonly PipeClient _pipe = new PipeClient();
        private readonly InputHook _hook = new InputHook();
        private readonly InputInjector _injector = new InputInjector();
        private readonly EdgeSwitchDetector _edgeSwitchDetector = new EdgeSwitchDetector(0);
        private readonly RemoteEdgeReturnDetector _remoteReturnDetector = new RemoteEdgeReturnDetector();
        private readonly ControlSessionController _session = new ControlSessionController();
        private readonly InputRoutingController _inputRouter = new InputRoutingController();
        private readonly DispatcherTimer _pollTimer = new DispatcherTimer();
        private readonly DispatcherTimer _stateTimer = new DispatcherTimer();

        private RemoteInputSender _remoteInputSender;
        private DirectInputChannel _directInputChannel;
        private RawMouseInputMonitor _rawMouseInput;
        private ClipboardSyncService _clipboardSync;
        private FileDropSender _fileDropSender;
        private Process _managedServiceProcess;
        private Forms.NotifyIcon _trayIcon;
        private PeerStateDto _state;
        private bool _remoteControlActive;
        private bool _controlledByPeer;
        private bool _pollInFlight;
        private bool _stateInFlight;
        private bool _settingsLoaded;
        private bool _applyingSettingsToUi;
        private bool _remoteReturnReleasePending;
        private bool _exitRequested;
        private bool _shutdownStarted;
        private bool _minimizeToTrayOnClose;
        private bool _blockScreenCorners;
        private bool _startWithWindows;
        private DateTime _remoteReturnReleasePendingUntilUtc = DateTime.MinValue;
        private DateTime _edgeSwitchCooldownUntilUtc = DateTime.MinValue;
        private DateTime _lastEdgeTraceUtc = DateTime.MinValue;
        private System.Drawing.Rectangle _localScreenBounds;
        private DrawingPoint _lastLocalMousePoint;
        private bool _hasLastLocalMousePoint;
        private int _remoteVirtualX;
        private int _remoteVirtualY;
        private DrawingSize _remoteVirtualScreen;
        private double _mouseSpeedMultiplier = 1.0;
        private int _mouseUpdateRateHz = 200;
        private string _pauseHotkey = "Ctrl+F11";
        private string _stopControlHotkey = "Ctrl+F10";
        private string _exitHotkey = "Ctrl+Alt+End";

        public MainWindow()
        {
            InitializeComponent();
            Loaded += OnLoaded;
            Closing += OnClosing;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            VersionText.Text = "LanMouseShare " + AppVersion;
            UpdatePauseButton();
            UpdateControlTargetText();
            AppLog.Info("Agent window loaded. Version=" + AppVersion);
            EnsureLocalServiceAvailable();

            try
            {
                _directInputChannel = new DirectInputChannel();
                _directInputChannel.InputBatchReceived += OnDirectInputBatchReceived;
            }
            catch (Exception ex)
            {
                AppLog.Error("Direct input channel unavailable; falling back to service input.", ex);
            }

            _remoteInputSender = new RemoteInputSender(_pipe, _directInputChannel);
            _remoteInputSender.SetMouseUpdateRate(_mouseUpdateRateHz);
            _remoteInputSender.SendFailed += OnRemoteInputSendFailed;

            _hook.InputCaptured += OnInputCaptured;
            _hook.Start();

            _rawMouseInput = new RawMouseInputMonitor();
            _rawMouseInput.Attach(this);
            _rawMouseInput.MouseMoved += OnRawMouseMoved;

            _clipboardSync = new ClipboardSyncService(_pipe, GetState, IsClipboardEnabled, Dispatcher);
            _clipboardSync.Attach(this);
            _fileDropSender = new FileDropSender(_pipe, GetState, IsControlPaused, Notify);

            _pollTimer.Interval = TimeSpan.FromMilliseconds(100);
            _pollTimer.Tick += OnPollEvents;
            _pollTimer.Start();

            _stateTimer.Interval = TimeSpan.FromSeconds(2);
            _stateTimer.Tick += delegate { RefreshStateAsync(); };
            _stateTimer.Start();

            RegisterScreenInfo();
            RefreshStateAsync();
        }

        private void OnClosing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!_exitRequested && _minimizeToTrayOnClose)
            {
                e.Cancel = true;
                HideToTray();
                return;
            }

            ShutdownAndDispose();
        }

        private void ShutdownAndDispose()
        {
            if (_shutdownStarted)
            {
                return;
            }

            _shutdownStarted = true;
            AppLog.Info("Agent closing.");
            StopControlEverywhere(true);
            RequestServiceShutdown();
            _pollTimer.Stop();
            _stateTimer.Stop();
            _hook.Dispose();
            if (_clipboardSync != null) _clipboardSync.Dispose();
            if (_remoteInputSender != null) _remoteInputSender.Dispose();
            if (_rawMouseInput != null) _rawMouseInput.Dispose();
            if (_directInputChannel != null) _directInputChannel.Dispose();
            if (_trayIcon != null)
            {
                _trayIcon.Visible = false;
                _trayIcon.Dispose();
                _trayIcon = null;
            }
        }

        private PeerStateDto GetState()
        {
            return _state;
        }

        private bool IsControlPaused()
        {
            return _session.IsPaused;
        }

        private bool IsClipboardEnabled()
        {
            return !_session.IsPaused && ClipboardEnabledBox != null && ClipboardEnabledBox.IsChecked == true;
        }

        private void RefreshStateAsync()
        {
            if (_stateInFlight)
            {
                return;
            }

            _stateInFlight = true;
            ThreadPool.QueueUserWorkItem(delegate
            {
                PeerStateDto state = null;
                Exception error = null;
                try
                {
                    var json = _pipe.Send(AgentCommands.GetPeerState, string.Empty, PipeConstants.StatusTimeoutMs);
                    state = ProtocolSerializer.FromJson<PeerStateDto>(json);
                }
                catch (Exception ex)
                {
                    error = ex;
                }

                Dispatcher.BeginInvoke(new Action(delegate
                {
                    _stateInFlight = false;
                    if (error != null)
                    {
                        SetStatus("服务未连接");
                        AppLog.Error("Refresh state failed.", error);
                        return;
                    }

                    ApplyState(state);
                }));
            });
        }

        private void ApplyState(PeerStateDto state)
        {
            _state = state;
            _session.ApplyState(state);
            if (state == null)
            {
                SetStatus("服务未连接");
                return;
            }

            LocalNameText.Text = state.LocalDeviceName ?? string.Empty;
            LocalIdText.Text = state.LocalDeviceId ?? string.Empty;
            PeerNameText.Text = state.PeerDeviceName ?? "未发现";
            PeerAddressText.Text = state.PeerAddress ?? string.Empty;
            TrustStateText.Text = TrustStateTextFor(state);
            LayoutText.Text = DirectionText(state.LayoutDirection);

            if (_directInputChannel != null)
            {
                _directInputChannel.SetPeer(state.IsConnected && state.IsTrusted ? state.PeerAddress : null);
            }

            ApplySettingsToUi(state);
            if ((!state.IsConnected || !state.IsTrusted) && (_session.IsTargetPeer || _remoteControlActive || _controlledByPeer))
            {
                ReleaseControl(false);
            }

            if (state.IsPairingMismatch)
            {
                SetStatus("配对异常，请重新配对");
            }
            else if (_session.IsPaused)
            {
                SetStatus("跨屏控制已暂停");
            }
            else if (state.IsConnected && state.IsTrusted)
            {
                SetStatus("已连接 " + (state.PeerDeviceName ?? state.PeerAddress));
            }
            else if (state.PairingStatus == PairingStatuses.PairedDisconnected)
            {
                SetStatus("已配对，等待对端连接");
            }
            else if (state.PairingStatus == PairingStatuses.WaitingForApproval)
            {
                SetStatus("等待对端确认配对");
            }
            else if (state.PeerDeviceName != null || state.PeerAddress != null)
            {
                SetStatus("发现设备，等待配对");
            }
            else
            {
                SetStatus("正在发现设备");
            }

            UpdateControlTargetText();
        }

        private static string TrustStateTextFor(PeerStateDto state)
        {
            if (state == null)
            {
                return "服务未连接";
            }

            if (state.IsPairingMismatch || state.PairingStatus == PairingStatuses.PairingMismatch)
            {
                return "配对异常";
            }

            if (state.PairingStatus == PairingStatuses.WaitingForApproval)
            {
                return "等待确认";
            }

            if (state.IsConnected && state.IsTrusted)
            {
                return "已配对";
            }

            if (state.PairingStatus == PairingStatuses.PairedDisconnected)
            {
                return "已配对，未连接";
            }

            return "未配对";
        }

        private void ApplySettingsToUi(PeerStateDto state)
        {
            _applyingSettingsToUi = true;
            _mouseSpeedMultiplier = state.MouseSpeedMultiplier <= 0 ? 1.0 : state.MouseSpeedMultiplier;
            _mouseUpdateRateHz = NormalizeMouseRate(state.MouseUpdateRateHz);
            _pauseHotkey = NormalizeHotkeyText(state.PauseHotkey, "Ctrl+F11");
            _stopControlHotkey = NormalizeHotkeyText(state.StopControlHotkey, "Ctrl+F10");
            _exitHotkey = NormalizeHotkeyText(state.ExitHotkey, "Ctrl+Alt+End");
            _startWithWindows = state.StartWithWindows;
            _minimizeToTrayOnClose = state.MinimizeToTrayOnClose;
            _blockScreenCorners = state.BlockScreenCorners;

            MouseSpeedSlider.Value = _mouseSpeedMultiplier;
            MouseSpeedText.Text = _mouseSpeedMultiplier.ToString("0.00") + "x";
            MouseRateText.Text = _mouseUpdateRateHz + "Hz";
            CurrentRateText.Text = _mouseUpdateRateHz + "Hz";
            ClipboardEnabledBox.IsChecked = state.ClipboardEnabled;
            PauseHotkeyBox.Text = _pauseHotkey;
            StopHotkeyBox.Text = _stopControlHotkey;
            ExitHotkeyBox.Text = _exitHotkey;
            StartWithWindowsBox.IsChecked = _startWithWindows;
            MinimizeToTrayBox.IsChecked = _minimizeToTrayOnClose;
            BlockCornersBox.IsChecked = _blockScreenCorners;
            SelectMouseRate(_mouseUpdateRateHz);
            if (_remoteInputSender != null)
            {
                _remoteInputSender.SetMouseUpdateRate(_mouseUpdateRateHz);
            }

            _settingsLoaded = true;
            _applyingSettingsToUi = false;
        }

        private void RegisterScreenInfo()
        {
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    var bounds = Forms.SystemInformation.VirtualScreen;
                    var payload = new ScreenInfoPayload { Width = bounds.Width, Height = bounds.Height };
                    _pipe.Send(AgentCommands.UpdateScreenInfo, ProtocolSerializer.ToJson(payload));
                }
                catch (Exception ex)
                {
                    AppLog.Error("UpdateScreenInfo failed.", ex);
                }
            });
        }

        private void OnInputCaptured(object sender, InputCapturedEventArgs e)
        {
            if (IsConfiguredHotkey(e.Payload, _stopControlHotkey))
            {
                e.SuppressLocalInput = true;
                StopControlEverywhere(true);
                return;
            }

            if (IsConfiguredHotkey(e.Payload, _pauseHotkey))
            {
                e.SuppressLocalInput = true;
                TogglePauseControl(true);
                return;
            }

            if (IsConfiguredHotkey(e.Payload, _exitHotkey))
            {
                e.SuppressLocalInput = true;
                ExitApplication();
                return;
            }

            var route = _inputRouter.Route(e.Payload, _session.Snapshot(_state));
            if (route == InputRouteAction.Ignore)
            {
                ResetEdgeSwitch("inactive");
                return;
            }

            if (route == InputRouteAction.ForwardToPeer)
            {
                HandleRemoteControlInput(e);
                return;
            }

            if (route == InputRouteAction.SuppressLocal)
            {
                e.SuppressLocalInput = true;
                return;
            }

            if (route == InputRouteAction.AllowLocal)
            {
                return;
            }

            var rawPoint = new DrawingPoint(e.Payload.X, e.Payload.Y);
            var screen = GetActiveScreenBounds(rawPoint.X, rawPoint.Y);
            var point = new DrawingPoint(rawPoint.X - screen.Left, rawPoint.Y - screen.Top);
            if (!_hasLastLocalMousePoint)
            {
                _lastLocalMousePoint = point;
                _hasLastLocalMousePoint = true;
                return;
            }

            var previousPoint = _lastLocalMousePoint;
            _lastLocalMousePoint = point;

            if (DateTime.UtcNow < _edgeSwitchCooldownUntilUtc)
            {
                return;
            }

            var shouldSwitch = _edgeSwitchDetector.ShouldSwitch(
                point,
                previousPoint,
                new DrawingSize(screen.Width, screen.Height),
                _state.LayoutDirection,
                _blockScreenCorners,
                CornerBlockPixels);
            if (shouldSwitch)
            {
                ActivateRemoteControl(point, screen);
                e.SuppressLocalInput = true;
            }
            else
            {
                LogEdgeTrace(point, previousPoint, screen);
            }
        }

        private void ActivateRemoteControl(DrawingPoint entryPoint, System.Drawing.Rectangle localScreen)
        {
            _remoteControlActive = true;
            _controlledByPeer = false;
            _session.SetPeerTarget();
            _localScreenBounds = localScreen;
            _remoteVirtualScreen = GetRemoteScreenSize(new DrawingSize(localScreen.Width, localScreen.Height));
            InitializeRemoteVirtualPosition(entryPoint, new DrawingSize(localScreen.Width, localScreen.Height));
            AppLog.Info("Remote control activated. Direction=" + _state.LayoutDirection +
                        " Entry=" + entryPoint.X + "," + entryPoint.Y +
                        " RemoteScreen=" + _remoteVirtualScreen.Width + "x" + _remoteVirtualScreen.Height);
            SendControlTarget(_session.ActiveTargetDeviceId, "EdgeSwitch");
            _remoteInputSender.SendCommand(AgentCommands.AcquireControl, "{}");
            _remoteInputSender.Enqueue(new InputPayload { Kind = InputKinds.MouseMove, X = _remoteVirtualX, Y = _remoteVirtualY });
            Notify("已切换控制", "正在控制 " + (_state.PeerDeviceName ?? "对端"));
            UpdateControlTargetText();
        }

        private void HandleRemoteControlInput(InputCapturedEventArgs e)
        {
            if (e.Payload.Kind == InputKinds.MouseMove)
            {
                e.SuppressLocalInput = true;
                return;
            }

            if (_remoteInputSender.Enqueue(e.Payload))
            {
                e.SuppressLocalInput = true;
                return;
            }

            AppLog.Warn("Remote input enqueue failed; releasing local control.");
            ReleaseControl(false);
        }

        private void OnRawMouseMoved(object sender, RawMouseMovedEventArgs e)
        {
            if (!_session.IsTargetPeer || _session.IsPaused)
            {
                return;
            }

            var dx = ScaleDelta(e.DeltaX);
            var dy = ScaleDelta(e.DeltaY);
            _remoteVirtualX += dx;
            _remoteVirtualY += dy;
            if (!_remoteInputSender.Enqueue(new InputPayload { Kind = InputKinds.MouseMoveRelative, X = dx, Y = dy }))
            {
                AppLog.Warn("Raw remote input enqueue failed; releasing remote control.");
                ReleaseControl(false);
            }
        }

        private void OnRemoteInputSendFailed(object sender, EventArgs e)
        {
            Dispatcher.BeginInvoke(new Action(delegate
            {
                if (_session.IsTargetPeer)
                {
                    ReleaseControl(false);
                }
            }));
        }

        private void OnDirectInputBatchReceived(object sender, InputBatchReceivedEventArgs e)
        {
            if (!_inputRouter.ShouldInjectRemoteInput(_session.Snapshot(_state)))
            {
                AppLog.Warn("Direct input ignored: local device is not the active target.");
                return;
            }

            for (int i = 0; i < e.Payloads.Length; i++)
            {
                InjectPeerInput(e.Payloads[i]);
            }
        }

        private void InjectPeerInput(InputPayload payload)
        {
            if (payload == null || !_inputRouter.ShouldInjectRemoteInput(_session.Snapshot(_state)))
            {
                return;
            }

            if (_remoteReturnReleasePending && DateTime.UtcNow >= _remoteReturnReleasePendingUntilUtc)
            {
                _remoteReturnReleasePending = false;
            }

            _injector.Inject(payload);
            if (!_remoteControlActive && !_controlledByPeer && !_remoteReturnReleasePending &&
                (payload.Kind == InputKinds.MouseMove || payload.Kind == InputKinds.MouseMoveRelative))
            {
                _controlledByPeer = true;
                _remoteReturnDetector.Reset();
                AppLog.Info("Remote control inferred from peer input.");
                UpdateControlTargetText();
            }

            if (_controlledByPeer && payload.Kind == InputKinds.MouseMoveRelative)
            {
                CheckRemoteReturnToController(payload.X, payload.Y);
            }
            else if (payload.Kind == InputKinds.MouseMove)
            {
                _remoteReturnDetector.Reset();
            }
        }

        private void CheckRemoteReturnToController(int deltaX, int deltaY)
        {
            if (_state == null || !_state.IsConnected || !_state.IsTrusted)
            {
                return;
            }

            var position = CursorController.GetPosition();
            var screen = GetActiveScreenBounds(position.X, position.Y);
            var point = new DrawingPoint(position.X - screen.Left, position.Y - screen.Top);
            var direction = _state.LayoutDirection ?? "Right";
            var result = _remoteReturnDetector.Update(point, new DrawingSize(screen.Width, screen.Height), direction, deltaX, deltaY, _session.IsPaused, _blockScreenCorners, CornerBlockPixels);
            if (!result.ShouldRelease || (_remoteReturnReleasePending && DateTime.UtcNow < _remoteReturnReleasePendingUntilUtc))
            {
                return;
            }

            _controlledByPeer = false;
            _session.SetPeerTarget();
            _remoteReturnDetector.Reset();
            _remoteReturnReleasePending = true;
            _remoteReturnReleasePendingUntilUtc = DateTime.UtcNow.AddMilliseconds(900);
            var payload = new ControlReleasePayload
            {
                RemoteX = point.X,
                RemoteY = point.Y,
                RemoteScreenWidth = screen.Width,
                RemoteScreenHeight = screen.Height,
                Direction = direction,
                Reason = result.Reason
            };
            AppLog.Info("Remote return requested. Direction=" + direction +
                        " Point=" + point.X + "," + point.Y +
                        " Delta=" + deltaX + "," + deltaY);
            SendControlTarget(_session.ActiveTargetDeviceId, "RemoteReturn");
            _remoteInputSender.SendCommand(AgentCommands.ReleaseControl, ProtocolSerializer.ToJson(payload));
            UpdateControlTargetText();
        }

        private void OnPollEvents(object sender, EventArgs e)
        {
            if (_pollInFlight)
            {
                return;
            }

            _pollInFlight = true;
            ThreadPool.QueueUserWorkItem(delegate
            {
                ProtocolEnvelope[] events = null;
                try
                {
                    var json = _pipe.Send(AgentCommands.PollEvents, string.Empty, PipeConstants.StatusTimeoutMs);
                    events = ProtocolSerializer.FromJson<ProtocolEnvelope[]>(json);
                }
                catch (Exception ex)
                {
                    AppLog.Error("Poll events failed.", ex);
                }

                Dispatcher.BeginInvoke(new Action(delegate
                {
                    _pollInFlight = false;
                    if (events == null)
                    {
                        return;
                    }

                    for (int i = 0; i < events.Length; i++)
                    {
                        ApplyEnvelope(events[i]);
                    }
                }));
            });
        }

        private void ApplyEnvelope(ProtocolEnvelope envelope)
        {
            if (envelope == null)
            {
                return;
            }

            if (envelope.MessageType == ProtocolMessageTypes.ControlPause)
            {
                ApplyPeerPause(envelope.PayloadJson);
                return;
            }

            if (envelope.MessageType == ProtocolMessageTypes.ControlResume)
            {
                ApplyPeerResume();
                return;
            }

            if (envelope.MessageType == ProtocolMessageTypes.ControlRelease)
            {
                ApplyPeerControlRelease(envelope.PayloadJson);
                return;
            }

            if (envelope.MessageType == ProtocolMessageTypes.ControlTargetChanged)
            {
                ApplyPeerControlTarget(envelope.PayloadJson);
                return;
            }

            if (_session.IsPaused && IsCrossScreenEnvelope(envelope.MessageType))
            {
                AppLog.Info("Envelope ignored while paused. Type=" + envelope.MessageType);
                return;
            }

            if (envelope.MessageType == ProtocolMessageTypes.InputEvent)
            {
                InjectPeerInput(ProtocolSerializer.FromJson<InputPayload>(envelope.PayloadJson));
            }
            else if (envelope.MessageType == ProtocolMessageTypes.InputBatch)
            {
                var batch = ProtocolSerializer.FromJson<InputBatchPayload>(envelope.PayloadJson);
                if (batch != null && batch.Events != null)
                {
                    for (int i = 0; i < batch.Events.Length; i++)
                    {
                        InjectPeerInput(batch.Events[i]);
                    }
                }
            }
            else if (envelope.MessageType == ProtocolMessageTypes.ControlAcquire)
            {
                _controlledByPeer = true;
                _remoteControlActive = false;
                _session.SetLocalTarget();
                _remoteReturnDetector.Reset();
                SetStatus("正在被对端控制");
                UpdateControlTargetText();
            }
            else if (envelope.MessageType == ProtocolMessageTypes.ClipboardUpdate)
            {
                _clipboardSync.ApplyRemote(ProtocolSerializer.FromJson<ClipboardPayload>(envelope.PayloadJson));
            }
            else if (envelope.MessageType == ProtocolMessageTypes.FileOffer)
            {
                Notify("正在接收文件", "文件将保存到桌面 Mouse传输文件 文件夹。");
            }
            else if (envelope.MessageType == ProtocolMessageTypes.FileComplete)
            {
                Notify("文件传输完成", "已保存到桌面 Mouse传输文件 文件夹。");
                OpenTransferFolder();
            }
        }

        private void ApplyPeerPause(string payloadJson)
        {
            var payload = ProtocolSerializer.FromJson<ControlPausePayload>(payloadJson);
            StopLocalCrossScreenState();
            _session.SetPaused(true);
            SetStatus(payload != null && payload.StopAll ? "控制已停止" : "跨屏控制已暂停");
            UpdatePauseButton();
            UpdateControlTargetText();
        }

        private void ApplyPeerResume()
        {
            _session.SetPaused(false);
            SetStatus("跨屏控制已恢复");
            UpdatePauseButton();
            UpdateControlTargetText();
        }

        private void ApplyPeerControlTarget(string payloadJson)
        {
            var payload = ProtocolSerializer.FromJson<ControlTargetPayload>(payloadJson);
            if (payload != null)
            {
                _session.SetTarget(payload.ActiveTargetDeviceId);
            }

            if (_session.IsTargetLocal)
            {
                _remoteControlActive = false;
                _controlledByPeer = true;
            }
            else if (_session.IsTargetPeer)
            {
                _remoteControlActive = true;
                _controlledByPeer = false;
            }

            UpdateControlTargetText();
        }

        private void ApplyPeerControlRelease(string payloadJson)
        {
            var payload = ProtocolSerializer.FromJson<ControlReleasePayload>(payloadJson);
            if (_remoteControlActive)
            {
                ReleaseControlToLocalEdge(payload);
                return;
            }

            _controlledByPeer = false;
            _remoteReturnReleasePending = false;
            _remoteReturnDetector.Reset();
            UpdateControlTargetText();
        }

        private void ReleaseControlToLocalEdge(ControlReleasePayload release)
        {
            var direction = _state != null ? _state.LayoutDirection : "Right";
            var localScreen = _localScreenBounds.Width > 0 ? _localScreenBounds : GetActiveScreenBounds(CursorController.GetPosition().X, CursorController.GetPosition().Y);
            var remoteWidth = release != null && release.RemoteScreenWidth > 0 ? release.RemoteScreenWidth : _remoteVirtualScreen.Width;
            var remoteHeight = release != null && release.RemoteScreenHeight > 0 ? release.RemoteScreenHeight : _remoteVirtualScreen.Height;
            var remoteX = release != null ? Clamp(release.RemoteX, 0, Math.Max(0, remoteWidth - 1)) : Clamp(_remoteVirtualX, 0, Math.Max(0, remoteWidth - 1));
            var remoteY = release != null ? Clamp(release.RemoteY, 0, Math.Max(0, remoteHeight - 1)) : Clamp(_remoteVirtualY, 0, Math.Max(0, remoteHeight - 1));
            ReleaseControl(false);
            _session.SetLocalTarget();

            int targetX;
            int targetY;
            if (direction == "Left")
            {
                targetX = localScreen.Left + 2;
                targetY = localScreen.Top + Clamp(Scale(remoteY, remoteHeight, localScreen.Height), 2, localScreen.Height - 3);
            }
            else if (direction == "Up")
            {
                targetX = localScreen.Left + Clamp(Scale(remoteX, remoteWidth, localScreen.Width), 2, localScreen.Width - 3);
                targetY = localScreen.Top + 2;
            }
            else if (direction == "Down")
            {
                targetX = localScreen.Left + Clamp(Scale(remoteX, remoteWidth, localScreen.Width), 2, localScreen.Width - 3);
                targetY = localScreen.Bottom - 2;
            }
            else
            {
                targetX = localScreen.Right - 2;
                targetY = localScreen.Top + Clamp(Scale(remoteY, remoteHeight, localScreen.Height), 2, localScreen.Height - 3);
            }

            CursorController.SetPosition(targetX, targetY);
            _edgeSwitchCooldownUntilUtc = DateTime.UtcNow.AddMilliseconds(600);
            ResetEdgeSwitch("return local");
            UpdateControlTargetText();
        }

        private void OnDropFiles(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                _fileDropSender.SendFiles((string[])e.Data.GetData(DataFormats.FileDrop));
            }
        }

        private void OnPairClicked(object sender, RoutedEventArgs e)
        {
            SendSimpleCommand(AgentCommands.PairDevice, PairingCodeBox.Text);
        }

        private void OnApproveClicked(object sender, RoutedEventArgs e)
        {
            SendSimpleCommand(AgentCommands.ApprovePairing, PairingCodeBox.Text);
        }

        private void OnUseManualIpClicked(object sender, RoutedEventArgs e)
        {
            SendSimpleCommand(AgentCommands.SetManualPeer, ManualIpBox.Text);
        }

        private void OnDirectionClicked(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            if (button == null || button.Tag == null)
            {
                return;
            }

            var layout = new LayoutConfig { PeerDirection = button.Tag.ToString() };
            var json = ProtocolSerializer.ToJson(layout);
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    _pipe.Send(AgentCommands.UpdateLayout, json);
                    RefreshStateAsync();
                }
                catch (Exception ex)
                {
                    AppLog.Error("Layout update failed.", ex);
                }
            });
        }

        private void OnRefreshClicked(object sender, RoutedEventArgs e)
        {
            RefreshStateAsync();
        }

        private void OnPauseClicked(object sender, RoutedEventArgs e)
        {
            TogglePauseControl(true);
        }

        private void OnStopControlClicked(object sender, RoutedEventArgs e)
        {
            StopControlEverywhere(true);
        }

        private void OnOpenTransferFolderClicked(object sender, RoutedEventArgs e)
        {
            OpenTransferFolder();
        }

        private void OnOpenLogsClicked(object sender, RoutedEventArgs e)
        {
            try
            {
                Directory.CreateDirectory(AppLog.LogDirectory);
                Process.Start("explorer.exe", AppLog.LogDirectory);
            }
            catch (Exception ex)
            {
                AppLog.Error("Open logs failed.", ex);
            }
        }

        private void OnMouseSpeedChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            _mouseSpeedMultiplier = e.NewValue;
            if (MouseSpeedText != null)
            {
                MouseSpeedText.Text = _mouseSpeedMultiplier.ToString("0.00") + "x";
            }

            SaveSettingsAsync();
        }

        private void OnMouseRateChanged(object sender, SelectionChangedEventArgs e)
        {
            _mouseUpdateRateHz = SelectedMouseRate();
            if (MouseRateText != null)
            {
                MouseRateText.Text = _mouseUpdateRateHz + "Hz";
            }

            if (CurrentRateText != null)
            {
                CurrentRateText.Text = _mouseUpdateRateHz + "Hz";
            }

            if (_remoteInputSender != null)
            {
                _remoteInputSender.SetMouseUpdateRate(_mouseUpdateRateHz);
            }

            SaveSettingsAsync();
        }

        private void OnSettingsChanged(object sender, RoutedEventArgs e)
        {
            SaveSettingsAsync();
        }

        private void OnHotkeyPreviewKeyDown(object sender, KeyEventArgs e)
        {
            var box = sender as TextBox;
            if (box == null)
            {
                return;
            }

            var key = e.Key == Key.System ? e.SystemKey : e.Key;
            key = key == Key.ImeProcessed ? e.ImeProcessedKey : key;
            if (IsModifierOnly(key))
            {
                e.Handled = true;
                return;
            }

            var text = BuildHotkeyText(Keyboard.Modifiers, key);
            if (!string.IsNullOrEmpty(text))
            {
                box.Text = text;
                SaveHotkeyFieldsFromUi();
                SaveSettingsAsync();
            }

            e.Handled = true;
        }

        private void OnHotkeyLostFocus(object sender, RoutedEventArgs e)
        {
            SaveHotkeyFieldsFromUi();
            SaveSettingsAsync();
        }

        private void SaveSettingsAsync()
        {
            if (!_settingsLoaded || _applyingSettingsToUi)
            {
                return;
            }

            SaveHotkeyFieldsFromUi();
            if (HasDuplicateHotkeys())
            {
                SetStatus("快捷键不能重复");
                return;
            }

            _startWithWindows = StartWithWindowsBox.IsChecked == true;
            _minimizeToTrayOnClose = MinimizeToTrayBox.IsChecked == true;
            _blockScreenCorners = BlockCornersBox.IsChecked == true;
            ApplyStartWithWindows(_startWithWindows);

            var settings = new AgentSettingsDto
            {
                MouseSpeedMultiplier = _mouseSpeedMultiplier,
                MouseUpdateRateHz = _mouseUpdateRateHz,
                ClipboardEnabled = ClipboardEnabledBox.IsChecked == true,
                PauseHotkey = _pauseHotkey,
                StopControlHotkey = _stopControlHotkey,
                ExitHotkey = _exitHotkey,
                StartWithWindows = _startWithWindows,
                MinimizeToTrayOnClose = _minimizeToTrayOnClose,
                BlockScreenCorners = _blockScreenCorners
            };
            var json = ProtocolSerializer.ToJson(settings);
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    _pipe.Send(AgentCommands.UpdateSettings, json);
                }
                catch (Exception ex)
                {
                    AppLog.Error("UpdateSettings failed.", ex);
                }
            });
        }

        private void SaveHotkeyFieldsFromUi()
        {
            _pauseHotkey = NormalizeHotkeyText(PauseHotkeyBox.Text, "Ctrl+F11");
            _stopControlHotkey = NormalizeHotkeyText(StopHotkeyBox.Text, "Ctrl+F10");
            _exitHotkey = NormalizeHotkeyText(ExitHotkeyBox.Text, "Ctrl+Alt+End");
            if (!string.Equals(PauseHotkeyBox.Text, _pauseHotkey, StringComparison.Ordinal))
            {
                PauseHotkeyBox.Text = _pauseHotkey;
            }

            if (!string.Equals(StopHotkeyBox.Text, _stopControlHotkey, StringComparison.Ordinal))
            {
                StopHotkeyBox.Text = _stopControlHotkey;
            }

            if (!string.Equals(ExitHotkeyBox.Text, _exitHotkey, StringComparison.Ordinal))
            {
                ExitHotkeyBox.Text = _exitHotkey;
            }
        }

        private bool HasDuplicateHotkeys()
        {
            return string.Equals(_pauseHotkey, _stopControlHotkey, StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(_pauseHotkey, _exitHotkey, StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(_stopControlHotkey, _exitHotkey, StringComparison.OrdinalIgnoreCase);
        }

        private void SendSimpleCommand(string command, string payload)
        {
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    _pipe.Send(command, payload);
                    RefreshStateAsync();
                }
                catch (Exception ex)
                {
                    AppLog.Error("Command failed. Command=" + command, ex);
                }
            });
        }

        private void SendControlTarget(string targetDeviceId, string reason)
        {
            if (_remoteInputSender == null || string.IsNullOrWhiteSpace(targetDeviceId))
            {
                return;
            }

            var payload = new ControlTargetPayload
            {
                ActiveTargetDeviceId = targetDeviceId,
                Reason = reason
            };
            _remoteInputSender.SendCommand(AgentCommands.SetControlTarget, ProtocolSerializer.ToJson(payload));
        }

        private void TogglePauseControl(bool notifyPeer)
        {
            if (_session.IsPaused)
            {
                _session.SetPaused(false);
                if (notifyPeer && _remoteInputSender != null)
                {
                    _remoteInputSender.SendCommand(AgentCommands.ResumeControl, "{}");
                }

                SetStatus("跨屏控制已恢复");
            }
            else
            {
                _session.SetPaused(true);
                StopLocalCrossScreenState();
                if (notifyPeer && _remoteInputSender != null)
                {
                    var payload = new ControlPausePayload { StopAll = false, Reason = "Pause" };
                    _remoteInputSender.SendCommand(AgentCommands.PauseControl, ProtocolSerializer.ToJson(payload));
                }

                SetStatus("跨屏控制已暂停");
            }

            UpdatePauseButton();
            UpdateControlTargetText();
        }

        private void StopControlEverywhere(bool notifyPeer)
        {
            _session.SetPaused(true);
            StopLocalCrossScreenState();
            if (notifyPeer && _remoteInputSender != null)
            {
                var payload = new ControlPausePayload { StopAll = true, Reason = "StopAll" };
                _remoteInputSender.SendCommand(AgentCommands.PauseControl, ProtocolSerializer.ToJson(payload));
            }

            SetStatus("控制已停止");
            UpdatePauseButton();
            UpdateControlTargetText();
        }

        private void StopLocalCrossScreenState()
        {
            _remoteControlActive = false;
            _controlledByPeer = false;
            _session.SetLocalTarget();
            _remoteReturnReleasePending = false;
            _remoteReturnDetector.Reset();
            ResetEdgeSwitch("stop local cross-screen");
            _hasLastLocalMousePoint = false;
            if (_remoteInputSender != null)
            {
                _remoteInputSender.Clear();
            }

            _injector.ReleaseAllMouseButtons();
        }

        private void ReleaseControl(bool notifyPeer)
        {
            var wasActive = _remoteControlActive;
            _remoteControlActive = false;
            _controlledByPeer = false;
            _session.SetLocalTarget();
            _remoteReturnReleasePending = false;
            _remoteReturnDetector.Reset();
            ResetEdgeSwitch("release");
            _hasLastLocalMousePoint = false;
            if (_remoteInputSender != null)
            {
                _remoteInputSender.Clear();
            }

            if (notifyPeer && wasActive && _remoteInputSender != null)
            {
                SendControlTarget(_session.ActiveTargetDeviceId, "Release");
                _remoteInputSender.SendCommand(AgentCommands.ReleaseControl, "{}");
            }

            if (_state != null && _state.IsConnected && !_session.IsPaused)
            {
                SetStatus("已连接 " + (_state.PeerDeviceName ?? _state.PeerAddress));
            }

            UpdateControlTargetText();
        }

        private void UpdatePauseButton()
        {
            if (PauseButton != null)
            {
                PauseButton.Content = _session.IsPaused ? "恢复" : "暂停";
            }
        }

        private void UpdateControlTargetText()
        {
            if (ControlTargetText == null)
            {
                return;
            }

            if (_session.IsPaused)
            {
                ControlTargetText.Text = "当前控制：本机（已暂停）";
            }
            else if (_session.IsTargetPeer)
            {
                ControlTargetText.Text = "当前控制：对端 " + (_state != null ? _state.PeerDeviceName ?? string.Empty : string.Empty);
            }
            else if (_session.IsTargetLocal && _controlledByPeer)
            {
                ControlTargetText.Text = "当前控制：本机（对端也可输入）";
            }
            else
            {
                ControlTargetText.Text = "当前控制：本机";
            }
        }

        private void HideToTray()
        {
            EnsureTrayIcon();
            _trayIcon.Visible = true;
            Hide();
            SetStatus("已最小化到托盘");
        }

        private void ShowFromTray()
        {
            Show();
            WindowState = WindowState.Normal;
            Activate();
        }

        private void EnsureTrayIcon()
        {
            if (_trayIcon != null)
            {
                return;
            }

            var menu = new Forms.ContextMenu();
            menu.MenuItems.Add("显示窗口", delegate { Dispatcher.BeginInvoke(new Action(ShowFromTray)); });
            menu.MenuItems.Add("暂停/恢复", delegate { Dispatcher.BeginInvoke(new Action(delegate { TogglePauseControl(true); })); });
            menu.MenuItems.Add("停止控制", delegate { Dispatcher.BeginInvoke(new Action(delegate { StopControlEverywhere(true); })); });
            menu.MenuItems.Add("-");
            menu.MenuItems.Add("退出", delegate { Dispatcher.BeginInvoke(new Action(ExitApplication)); });

            _trayIcon = new Forms.NotifyIcon();
            _trayIcon.Text = "LanMouseShare " + AppVersion;
            _trayIcon.Icon = System.Drawing.SystemIcons.Application;
            _trayIcon.ContextMenu = menu;
            _trayIcon.DoubleClick += delegate { Dispatcher.BeginInvoke(new Action(ShowFromTray)); };
        }

        private void ExitApplication()
        {
            _exitRequested = true;
            Close();
        }

        private void EnsureLocalServiceAvailable()
        {
            if (CanReachService())
            {
                return;
            }

            StartAgentManagedService();
        }

        private bool CanReachService()
        {
            try
            {
                _pipe.Send(AgentCommands.GetPeerState, string.Empty, 500);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private void StartAgentManagedService()
        {
            try
            {
                var agentDirectory = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
                var servicePath = Path.GetFullPath(Path.Combine(agentDirectory, "..", "Service", "LanMouseShare.Service.exe"));
                if (!File.Exists(servicePath))
                {
                    servicePath = Path.Combine(agentDirectory, "LanMouseShare.Service.exe");
                }

                if (!File.Exists(servicePath))
                {
                    AppLog.Warn("Agent-managed service executable not found.");
                    return;
                }

                var startInfo = new ProcessStartInfo(servicePath, "--agent");
                startInfo.WorkingDirectory = Path.GetDirectoryName(servicePath);
                startInfo.UseShellExecute = false;
                startInfo.CreateNoWindow = true;
                _managedServiceProcess = Process.Start(startInfo);

                for (int i = 0; i < 20; i++)
                {
                    if (CanReachService())
                    {
                        return;
                    }

                    Thread.Sleep(100);
                }
            }
            catch (Exception ex)
            {
                AppLog.Error("Start agent-managed service failed.", ex);
            }
        }

        private void RequestServiceShutdown()
        {
            try
            {
                _pipe.Send(AgentCommands.ShutdownService, string.Empty, 1000);
            }
            catch
            {
            }

            try
            {
                if (_managedServiceProcess != null)
                {
                    _managedServiceProcess.WaitForExit(1500);
                    _managedServiceProcess = null;
                }
            }
            catch
            {
            }

            StopWindowsServiceFallback();
        }

        private static void StopWindowsServiceFallback()
        {
            try
            {
                var startInfo = new ProcessStartInfo("sc.exe", "stop LanMouseShare");
                startInfo.UseShellExecute = false;
                startInfo.CreateNoWindow = true;
                using (var process = Process.Start(startInfo))
                {
                    process.WaitForExit(1500);
                }
            }
            catch
            {
            }
        }

        private void ApplyStartWithWindows(bool enabled)
        {
            try
            {
                using (var key = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run"))
                {
                    if (enabled)
                    {
                        var path = System.Reflection.Assembly.GetEntryAssembly().Location;
                        key.SetValue(RunValueName, "\"" + path + "\"");
                    }
                    else
                    {
                        key.DeleteValue(RunValueName, false);
                    }
                }
            }
            catch (Exception ex)
            {
                AppLog.Error("Update startup registry failed.", ex);
                SetStatus("开机自启动设置失败");
            }
        }

        private DrawingSize GetRemoteScreenSize(DrawingSize fallback)
        {
            if (_state != null && _state.PeerScreenWidth > 0 && _state.PeerScreenHeight > 0)
            {
                return new DrawingSize(_state.PeerScreenWidth, _state.PeerScreenHeight);
            }

            return fallback;
        }

        private void InitializeRemoteVirtualPosition(DrawingPoint entryPoint, DrawingSize localScreen)
        {
            const int inset = 8;
            var direction = _state != null ? _state.LayoutDirection : "Right";
            if (direction == "Left")
            {
                _remoteVirtualX = _remoteVirtualScreen.Width - inset;
                _remoteVirtualY = Scale(entryPoint.Y, localScreen.Height, _remoteVirtualScreen.Height);
            }
            else if (direction == "Up")
            {
                _remoteVirtualX = Scale(entryPoint.X, localScreen.Width, _remoteVirtualScreen.Width);
                _remoteVirtualY = _remoteVirtualScreen.Height - inset;
            }
            else if (direction == "Down")
            {
                _remoteVirtualX = Scale(entryPoint.X, localScreen.Width, _remoteVirtualScreen.Width);
                _remoteVirtualY = inset;
            }
            else
            {
                _remoteVirtualX = inset;
                _remoteVirtualY = Scale(entryPoint.Y, localScreen.Height, _remoteVirtualScreen.Height);
            }
        }

        private System.Drawing.Rectangle GetActiveScreenBounds(int x, int y)
        {
            return DesktopEnvironment.GetScreenBoundsFromPoint(x, y);
        }

        private int ScaleDelta(int delta)
        {
            if (delta == 0)
            {
                return 0;
            }

            var scaled = (int)Math.Round(delta * _mouseSpeedMultiplier);
            if (scaled == 0)
            {
                return delta > 0 ? 1 : -1;
            }

            return scaled;
        }

        private void ResetEdgeSwitch(string reason)
        {
            AppLog.Info("Edge switch reset. Reason=" + reason);
        }

        private void LogEdgeTrace(DrawingPoint point, DrawingPoint previousPoint, System.Drawing.Rectangle screen)
        {
            if ((DateTime.UtcNow - _lastEdgeTraceUtc).TotalMilliseconds < 500)
            {
                return;
            }

            _lastEdgeTraceUtc = DateTime.UtcNow;
            AppLog.Info("EdgeTrace Direction=" + (_state != null ? _state.LayoutDirection : "?") +
                        " Point=" + point.X + "," + point.Y +
                        " Previous=" + previousPoint.X + "," + previousPoint.Y +
                        " Screen=" + screen.Width + "x" + screen.Height +
                        " BlockCorners=" + _blockScreenCorners);
        }

        private static bool IsCrossScreenEnvelope(string messageType)
        {
            return messageType == ProtocolMessageTypes.InputEvent ||
                   messageType == ProtocolMessageTypes.InputBatch ||
                   messageType == ProtocolMessageTypes.ClipboardUpdate ||
                   messageType == ProtocolMessageTypes.FileOffer ||
                   messageType == ProtocolMessageTypes.FileStreamStart ||
                   messageType == ProtocolMessageTypes.FileComplete ||
                   messageType == ProtocolMessageTypes.ControlAcquire;
        }

        private static bool IsConfiguredHotkey(InputPayload payload, string hotkeyText)
        {
            if (payload == null || payload.Kind != InputKinds.Key || !payload.IsDown || string.IsNullOrWhiteSpace(hotkeyText))
            {
                return false;
            }

            Forms.Keys key;
            bool needCtrl;
            bool needAlt;
            bool needShift;
            if (!TryParseHotkey(hotkeyText, out key, out needCtrl, out needAlt, out needShift))
            {
                return false;
            }

            var modifiers = Forms.Control.ModifierKeys;
            var hasCtrl = (modifiers & Forms.Keys.Control) == Forms.Keys.Control;
            var hasAlt = (modifiers & Forms.Keys.Alt) == Forms.Keys.Alt;
            var hasShift = (modifiers & Forms.Keys.Shift) == Forms.Keys.Shift;
            return payload.VirtualKey == (int)key &&
                   hasCtrl == needCtrl &&
                   hasAlt == needAlt &&
                   hasShift == needShift;
        }

        private static bool TryParseHotkey(string text, out Forms.Keys key, out bool ctrl, out bool alt, out bool shift)
        {
            key = Forms.Keys.None;
            ctrl = false;
            alt = false;
            shift = false;
            var parts = (text ?? string.Empty).Split(new[] { '+' }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < parts.Length; i++)
            {
                var part = parts[i].Trim();
                if (string.Equals(part, "Ctrl", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(part, "Control", StringComparison.OrdinalIgnoreCase))
                {
                    ctrl = true;
                }
                else if (string.Equals(part, "Alt", StringComparison.OrdinalIgnoreCase))
                {
                    alt = true;
                }
                else if (string.Equals(part, "Shift", StringComparison.OrdinalIgnoreCase))
                {
                    shift = true;
                }
                else
                {
                    try
                    {
                        key = (Forms.Keys)Enum.Parse(typeof(Forms.Keys), part, true);
                    }
                    catch
                    {
                        return false;
                    }
                }
            }

            return key != Forms.Keys.None;
        }

        private static string NormalizeHotkeyText(string text, string fallback)
        {
            Forms.Keys key;
            bool ctrl;
            bool alt;
            bool shift;
            if (!TryParseHotkey(text, out key, out ctrl, out alt, out shift))
            {
                return fallback;
            }

            var result = string.Empty;
            if (ctrl) result += "Ctrl+";
            if (alt) result += "Alt+";
            if (shift) result += "Shift+";
            return result + key;
        }

        private static string BuildHotkeyText(ModifierKeys modifiers, Key key)
        {
            var virtualKey = KeyInterop.VirtualKeyFromKey(key);
            if (virtualKey <= 0)
            {
                return null;
            }

            var result = string.Empty;
            if ((modifiers & ModifierKeys.Control) == ModifierKeys.Control) result += "Ctrl+";
            if ((modifiers & ModifierKeys.Alt) == ModifierKeys.Alt) result += "Alt+";
            if ((modifiers & ModifierKeys.Shift) == ModifierKeys.Shift) result += "Shift+";
            return result + ((Forms.Keys)virtualKey);
        }

        private static bool IsModifierOnly(Key key)
        {
            return key == Key.LeftCtrl || key == Key.RightCtrl ||
                   key == Key.LeftAlt || key == Key.RightAlt ||
                   key == Key.LeftShift || key == Key.RightShift ||
                   key == Key.LWin || key == Key.RWin;
        }

        private static int Scale(int value, int source, int target)
        {
            return source <= 0 ? 0 : value * target / source;
        }

        private static int Clamp(int value, int min, int max)
        {
            if (max < min)
            {
                return min;
            }

            if (value < min) return min;
            if (value > max) return max;
            return value;
        }

        private static int NormalizeMouseRate(int rateHz)
        {
            if (rateHz <= 0) return 200;
            if (rateHz < 60) return 60;
            if (rateHz > 250) return 250;
            return rateHz;
        }

        private int SelectedMouseRate()
        {
            var item = MouseRateBox != null ? MouseRateBox.SelectedItem as ComboBoxItem : null;
            var text = item != null ? item.Content as string : null;
            if (string.IsNullOrEmpty(text))
            {
                return _mouseUpdateRateHz;
            }

            int value;
            return int.TryParse(text.Replace("Hz", string.Empty), out value) ? value : _mouseUpdateRateHz;
        }

        private void SelectMouseRate(int rateHz)
        {
            if (MouseRateBox == null)
            {
                return;
            }

            for (int i = 0; i < MouseRateBox.Items.Count; i++)
            {
                var item = MouseRateBox.Items[i] as ComboBoxItem;
                if (item != null && string.Equals(item.Content as string, rateHz + "Hz", StringComparison.OrdinalIgnoreCase))
                {
                    MouseRateBox.SelectedIndex = i;
                    return;
                }
            }
        }

        private static string DirectionText(string direction)
        {
            if (direction == "Left") return "对端在左";
            if (direction == "Up") return "对端在上";
            if (direction == "Down") return "对端在下";
            return "对端在右";
        }

        private void OpenTransferFolder()
        {
            try
            {
                var folder = GetTransferDirectory();
                Directory.CreateDirectory(folder);
                Process.Start("explorer.exe", folder);
            }
            catch (Exception ex)
            {
                AppLog.Error("Open transfer folder failed.", ex);
            }
        }

        private static string GetTransferDirectory()
        {
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "Mouse传输文件");
        }

        private void Notify(string title, string message)
        {
            Dispatcher.BeginInvoke(new Action(delegate
            {
                SetStatus(title);
                HintText.Text = message ?? string.Empty;
            }));
            AppLog.Info(title + " " + message);
        }

        private void SetStatus(string text)
        {
            StatusText.Text = text ?? string.Empty;
        }
    }
}
