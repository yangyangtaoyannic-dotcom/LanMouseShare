using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("LanMouseShare.Tests")]
[assembly: AssemblyCompany("LanMouseShare")]
[assembly: AssemblyProduct("LanMouseShare")]
[assembly: ComVisible(false)]
[assembly: Guid("b2f92630-6a9c-4b3e-9f5f-dc090967a758")]
[assembly: AssemblyVersion("0.1.42.0")]
[assembly: AssemblyFileVersion("0.1.42.0")]
