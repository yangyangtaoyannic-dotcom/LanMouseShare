using System;
using System.Drawing;
using System.IO;
using System.Text;
using LanMouseShare.Core.Configuration;
using LanMouseShare.Core.Control;
using LanMouseShare.Core.Crypto;
using LanMouseShare.Core.Ipc;
using LanMouseShare.Core.Protocol;
using LanMouseShare.Input;

namespace LanMouseShare.Tests
{
    internal static class Program
    {
        private static int Main()
        {
            try
            {
                SecureChannelRoundTrips();
                TamperDetectionWorks();
                ProtocolSerializationRoundTrips();
                ClipboardPayloadRoundTrips();
                SettingsDefaultsWork();
                FileTransferRequestRoundTrips();
                ControlTargetPayloadRoundTrips();
                InputRoutingFollowsActiveTarget();
                ScrollViewerExistsInAgentUi();
                ControlTokenRejectsSecondOwner();
                EdgeSwitchDetectionWorks();
                EdgeCornerBlockingWorks();
                PhysicalEdgeSwitchDetectionWorks();
                RemoteEdgeReturnDetectionWorks();
                DpiCoordinateMappingWorks();
                Console.WriteLine("All tests passed.");
                return 0;
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine(ex);
                return 1;
            }
        }

        private static void SecureChannelRoundTrips()
        {
            var secret = SecureRandom.Bytes(32);
            var protector = new SecureChannelProtector(secret);
            var plaintext = Encoding.UTF8.GetBytes("hello win7");
            var protectedBytes = protector.Protect(plaintext);
            var unprotected = protector.Unprotect(protectedBytes);
            Assert(Encoding.UTF8.GetString(unprotected) == "hello win7", "Secure channel round trip failed.");
        }

        private static void TamperDetectionWorks()
        {
            var protector = new SecureChannelProtector(SecureRandom.Bytes(32));
            var protectedBytes = protector.Protect(Encoding.UTF8.GetBytes("secret"));
            protectedBytes[20] ^= 0x20;

            bool failed = false;
            try
            {
                protector.Unprotect(protectedBytes);
            }
            catch
            {
                failed = true;
            }

            Assert(failed, "Tampered payload was accepted.");
        }

        private static void ProtocolSerializationRoundTrips()
        {
            var payload = new InputPayload
            {
                Kind = InputKinds.Key,
                VirtualKey = 65,
                ScanCode = 30,
                Flags = 1,
                IsExtendedKey = true,
                IsSystemKey = true,
                IsDown = true
            };
            var json = ProtocolSerializer.ToJson(payload);
            var clone = ProtocolSerializer.FromJson<InputPayload>(json);
            Assert(clone.Kind == InputKinds.Key &&
                   clone.VirtualKey == 65 &&
                   clone.ScanCode == 30 &&
                   clone.Flags == 1 &&
                   clone.IsExtendedKey &&
                   clone.IsSystemKey &&
                   clone.IsDown, "Protocol serialization failed.");
        }

        private static void SettingsDefaultsWork()
        {
            var config = new AppConfig();
            ConfigStore.ApplyDefaults(config);
            Assert(config.MouseSpeedMultiplier == 1.0, "Default mouse speed failed.");
            Assert(config.MouseUpdateRateHz == 200, "Default mouse update rate failed.");

            var settings = new AgentSettingsDto
            {
                MouseSpeedMultiplier = 1.25,
                MouseUpdateRateHz = 250,
                ClipboardEnabled = false,
                PauseHotkey = "Ctrl+F11",
                StopControlHotkey = "Ctrl+F10",
                ExitHotkey = "Ctrl+Alt+End",
                StartWithWindows = true,
                MinimizeToTrayOnClose = true,
                BlockScreenCorners = true
            };
            var clone = ProtocolSerializer.FromJson<AgentSettingsDto>(ProtocolSerializer.ToJson(settings));
            Assert(clone.MouseUpdateRateHz == 250 &&
                   !clone.ClipboardEnabled &&
                   clone.StopControlHotkey == "Ctrl+F10" &&
                   clone.ExitHotkey == "Ctrl+Alt+End" &&
                   clone.StartWithWindows &&
                   clone.MinimizeToTrayOnClose &&
                   clone.BlockScreenCorners,
                "Settings serialization failed.");
        }

        private static void ClipboardPayloadRoundTrips()
        {
            var text = new ClipboardPayload
            {
                OriginDeviceId = "local",
                Version = 7,
                Format = ClipboardFormats.Text,
                Text = "hello clipboard"
            };
            var textClone = ProtocolSerializer.FromJson<ClipboardPayload>(ProtocolSerializer.ToJson(text));
            Assert(textClone.Format == ClipboardFormats.Text && textClone.Text == "hello clipboard" && textClone.Version == 7,
                "Text clipboard serialization failed.");

            var image = new ClipboardPayload
            {
                OriginDeviceId = "local",
                Version = 8,
                Format = ClipboardFormats.ImagePng,
                ImagePngBytes = new byte[] { 1, 2, 3, 4 }
            };
            var imageClone = ProtocolSerializer.FromJson<ClipboardPayload>(ProtocolSerializer.ToJson(image));
            Assert(imageClone.Format == ClipboardFormats.ImagePng && imageClone.ImagePngBytes.Length == 4 && imageClone.ImagePngBytes[2] == 3,
                "Image clipboard serialization failed.");
        }

        private static void FileTransferRequestRoundTrips()
        {
            var request = new FileTransferRequestPayload
            {
                FilePaths = new[] { @"C:\Temp\a.txt", @"C:\Temp\b.txt" }
            };
            var clone = ProtocolSerializer.FromJson<FileTransferRequestPayload>(ProtocolSerializer.ToJson(request));
            Assert(clone.FilePaths.Length == 2 && clone.FilePaths[1].EndsWith("b.txt"), "File transfer request serialization failed.");
        }

        private static void ControlTargetPayloadRoundTrips()
        {
            var payload = new ControlTargetPayload
            {
                ActiveTargetDeviceId = "device-b",
                Reason = "EdgeSwitch"
            };
            var clone = ProtocolSerializer.FromJson<ControlTargetPayload>(ProtocolSerializer.ToJson(payload));
            Assert(clone.ActiveTargetDeviceId == "device-b" && clone.Reason == "EdgeSwitch",
                "Control target payload serialization failed.");
        }

        private static void InputRoutingFollowsActiveTarget()
        {
            var router = new InputRoutingController();
            var key = new InputPayload { Kind = InputKinds.Key, VirtualKey = 65, IsDown = true };
            var mouse = new InputPayload { Kind = InputKinds.MouseMove, X = 799, Y = 300 };

            var targetLocal = new ControlSessionSnapshot
            {
                IsConnected = true,
                LocalDeviceId = "a",
                PeerDeviceId = "b",
                ActiveTargetDeviceId = "a"
            };
            Assert(router.Route(key, targetLocal) == InputRouteAction.AllowLocal,
                "Local target should allow local keyboard input.");
            Assert(router.Route(mouse, targetLocal) == InputRouteAction.CheckEdgeSwitch,
                "Local target mouse move should check edge switching.");
            Assert(router.ShouldInjectRemoteInput(targetLocal),
                "Local target should accept remote keyboard injection.");

            var targetPeer = new ControlSessionSnapshot
            {
                IsConnected = true,
                LocalDeviceId = "b",
                PeerDeviceId = "a",
                ActiveTargetDeviceId = "a"
            };
            Assert(router.Route(key, targetPeer) == InputRouteAction.ForwardToPeer,
                "Peer target should forward keyboard input.");
            Assert(router.Route(mouse, targetPeer) == InputRouteAction.SuppressLocal,
                "Peer target absolute mouse move should be suppressed locally.");
            Assert(!router.ShouldInjectRemoteInput(targetPeer),
                "Peer target should not inject remote input locally.");

            targetPeer.IsPaused = true;
            Assert(router.Route(key, targetPeer) == InputRouteAction.Ignore,
                "Paused sessions should ignore input.");
        }

        private static void ScrollViewerExistsInAgentUi()
        {
            var path = Path.Combine("src", "Desktop.Agent", "MainWindow.xaml");
            if (!File.Exists(path))
            {
                path = Path.Combine("..", "..", "..", "src", "Desktop.Agent", "MainWindow.xaml");
            }

            var xaml = File.ReadAllText(path);
            Assert(xaml.Contains("<ScrollViewer") && xaml.Contains("VerticalScrollBarVisibility=\"Auto\""),
                "Agent UI should contain an auto vertical ScrollViewer.");
        }

        private static void ControlTokenRejectsSecondOwner()
        {
            var state = new ControlTokenState();
            Assert(state.TryAcquire("a"), "First owner should acquire.");
            Assert(!state.TryAcquire("b"), "Second owner should be rejected.");
            state.Release("a");
            Assert(state.TryAcquire("b"), "Second owner should acquire after release.");
        }

        private static void EdgeSwitchDetectionWorks()
        {
            var detector = new EdgeSwitchDetector(0);
            Assert(detector.ShouldSwitch(new Point(799, 300), new Size(800, 600), "Right"), "Right edge not detected.");
            Assert(detector.ShouldSwitch(new Point(799, 300), new Point(798, 300), new Size(800, 600), "Right"), "Right outward movement not detected.");
            Assert(!detector.ShouldSwitch(new Point(799, 300), new Point(799, 300), new Size(800, 600), "Right"), "Stationary edge point should not switch.");
            Assert(!detector.ShouldSwitch(new Point(798, 300), new Point(799, 300), new Size(800, 600), "Right"), "Inward movement should not switch.");
            Assert(!detector.ShouldSwitch(new Point(400, 300), new Size(800, 600), "Right"), "Center should not switch.");
            Assert(detector.ShouldSwitch(new Point(0, 300), new Point(1, 300), new Size(800, 600), "Left"), "Left outward movement not detected.");
            Assert(detector.ShouldSwitch(new Point(300, 0), new Point(300, 1), new Size(800, 600), "Up"), "Up outward movement not detected.");
            Assert(detector.ShouldSwitch(new Point(300, 599), new Point(300, 598), new Size(800, 600), "Down"), "Down outward movement not detected.");
        }

        private static void PhysicalEdgeSwitchDetectionWorks()
        {
            var detector = new EdgeSwitchDetector(0);
            var screen = new Size(800, 600);
            Assert(!detector.ShouldSwitch(new Point(798, 300), screen, "Right"),
                "Inside right edge should not be treated as physical edge.");
            Assert(detector.ShouldSwitch(new Point(799, 300), screen, "Right"),
                "Right edge contact should be exact.");
            Assert(detector.ShouldSwitch(new Point(799, 300), new Point(100, 300), screen, "Right"),
                "Fast right movement to the physical edge should switch.");
            Assert(detector.ShouldSwitch(new Point(0, 300), new Point(700, 300), screen, "Left"),
                "Fast left movement to the physical edge should switch.");
            Assert(detector.ShouldSwitch(new Point(300, 0), new Point(300, 500), screen, "Up"),
                "Fast up movement to the physical edge should switch.");
            Assert(detector.ShouldSwitch(new Point(300, 599), new Point(300, 10), screen, "Down"),
                "Fast down movement to the physical edge should switch.");
        }

        private static void EdgeCornerBlockingWorks()
        {
            var detector = new EdgeSwitchDetector(0);
            var screen = new Size(800, 600);
            Assert(!detector.ShouldSwitch(new Point(799, 20), new Point(798, 20), screen, "Right", true, 80),
                "Right top blocked corner should not switch.");
            Assert(!detector.ShouldSwitch(new Point(799, 580), new Point(798, 580), screen, "Right", true, 80),
                "Right bottom blocked corner should not switch.");
            Assert(detector.ShouldSwitch(new Point(799, 300), new Point(798, 300), screen, "Right", true, 80),
                "Right edge middle should still switch.");
            Assert(detector.ShouldSwitch(new Point(799, 20), new Point(798, 20), screen, "Right", false, 80),
                "Disabled corner blocking should not affect switching.");
            Assert(!detector.ShouldSwitch(new Point(20, 0), new Point(20, 1), screen, "Up", true, 80),
                "Top left blocked corner should not switch.");
            Assert(detector.ShouldSwitch(new Point(400, 0), new Point(400, 1), screen, "Up", true, 80),
                "Top edge middle should still switch.");
        }

        private static void RemoteEdgeReturnDetectionWorks()
        {
            var detector = new RemoteEdgeReturnDetector();
            var screen = new Size(800, 600);
            var result = detector.Update(new Point(10, 300), screen, "Left", -20, 0, false, false, 0);
            Assert(!result.ShouldRelease && result.Reason == "AwayFromEdge",
                "Remote return should not release before the real cursor reaches the edge.");

            result = detector.Update(new Point(0, 300), screen, "Left", -10, 0, false, false, 0);
            Assert(result.ShouldRelease && result.Reason == "RealEdgeOutward",
                "Outward movement at the real edge should release immediately.");

            detector = new RemoteEdgeReturnDetector();
            result = detector.Update(new Point(799, 300), screen, "Right", 10, 0, false, false, 0);
            Assert(result.ShouldRelease, "Right edge outward push should release.");

            detector = new RemoteEdgeReturnDetector();
            result = detector.Update(new Point(300, 0), screen, "Up", 0, -10, false, false, 0);
            Assert(result.ShouldRelease, "Up edge outward push should release.");

            detector = new RemoteEdgeReturnDetector();
            result = detector.Update(new Point(300, 599), screen, "Down", 0, 10, false, false, 0);
            Assert(result.ShouldRelease, "Down edge outward push should release.");

            detector = new RemoteEdgeReturnDetector();
            result = detector.Update(new Point(0, 300), screen, "Left", 0, 12, false, false, 0);
            Assert(!result.ShouldRelease && result.Reason == "Armed",
                "Vertical movement along the return edge should not release.");
        }

        private static void DpiCoordinateMappingWorks()
        {
            Assert(AreNearlyEqual(DpiCoordinateMapper.PixelsToDip(1920, 96), 1920), "96 DPI conversion failed.");
            Assert(AreNearlyEqual(DpiCoordinateMapper.PixelsToDip(1920, 120), 1536), "120 DPI conversion failed.");
            Assert(AreNearlyEqual(DpiCoordinateMapper.PixelsToDip(1920, 144), 1280), "144 DPI conversion failed.");
            Assert(AreNearlyEqual(DpiCoordinateMapper.PixelsToDip(1920, 192), 960), "192 DPI conversion failed.");

            var scale120 = new DpiScale(120, 120);
            var pixelRect = Rectangle.FromLTRB(200, 100, 2120, 1180);
            var dipRect = DpiCoordinateMapper.PixelRectToDip(pixelRect, scale120);
            Assert(AreNearlyEqual(dipRect.Left, DpiCoordinateMapper.PixelsToDip(pixelRect.Left, 120)), "Rect left conversion mismatch.");
            Assert(AreNearlyEqual(dipRect.Right, DpiCoordinateMapper.PixelsToDip(pixelRect.Right, 120)), "Rect right conversion mismatch.");
            Assert(AreNearlyEqual(dipRect.Width, DpiCoordinateMapper.PixelsToDip(pixelRect.Width, 120)), "Rect width conversion mismatch.");

            var edgePixelRect = Rectangle.FromLTRB(2536, 0, 2560, 1440);
            var edgeDipRect = DpiCoordinateMapper.PixelRectToDip(edgePixelRect, new DpiScale(144, 144));
            Assert(AreNearlyEqual(edgeDipRect.Right, DpiCoordinateMapper.PixelsToDip(edgePixelRect.Right, 144)),
                "Right-edge mapping should stay aligned after DIP conversion.");

            var wideEdgePixelRect = Rectangle.FromLTRB(2496, 0, 2560, 1440);
            var wideEdgeDipRect = DpiCoordinateMapper.PixelRectToDip(wideEdgePixelRect, new DpiScale(144, 144));
            Assert(AreNearlyEqual(wideEdgeDipRect.Width, DpiCoordinateMapper.PixelsToDip(wideEdgePixelRect.Width, 144)),
                "Wide edge capture mapping should preserve physical width after DIP conversion.");
        }

        private static void Assert(bool condition, string message)
        {
            if (!condition)
            {
                throw new InvalidOperationException(message);
            }
        }

        private static bool AreNearlyEqual(double left, double right)
        {
            return Math.Abs(left - right) < 0.01;
        }
    }
}
