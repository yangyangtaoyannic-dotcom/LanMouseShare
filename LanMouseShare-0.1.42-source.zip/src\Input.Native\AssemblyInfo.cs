using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("LanMouseShare.Input")]
[assembly: AssemblyDescription("Win7-compatible native input hooks and injection.")]
[assembly: AssemblyCompany("LanMouseShare")]
[assembly: AssemblyProduct("LanMouseShare")]
[assembly: ComVisible(false)]
[assembly: Guid("2dc737ef-7185-4d00-89d2-46375493c820")]
[assembly: AssemblyVersion("0.1.42.0")]
[assembly: AssemblyFileVersion("0.1.42.0")]
