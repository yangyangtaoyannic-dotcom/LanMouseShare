using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("LanMouseShare.Service")]
[assembly: AssemblyDescription("Windows service for LAN discovery, pairing, transport, and file transfer.")]
[assembly: AssemblyCompany("LanMouseShare")]
[assembly: AssemblyProduct("LanMouseShare")]
[assembly: ComVisible(false)]
[assembly: Guid("853983bc-ae41-4874-88e0-185e01820e5c")]
[assembly: AssemblyVersion("0.1.42.0")]
[assembly: AssemblyFileVersion("0.1.42.0")]
