using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("LanMouseShare.Core")]
[assembly: AssemblyDescription("Shared protocol, crypto, config, and LAN discovery primitives.")]
[assembly: AssemblyCompany("LanMouseShare")]
[assembly: AssemblyProduct("LanMouseShare")]
[assembly: ComVisible(false)]
[assembly: Guid("e52b27fc-8bbe-46ce-83e1-7f95828f9c2f")]
[assembly: AssemblyVersion("0.1.42.0")]
[assembly: AssemblyFileVersion("0.1.42.0")]
