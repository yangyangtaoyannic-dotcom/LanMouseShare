namespace LanMouseShare.Core.Ipc
{
    public static class PipeConstants
    {
        public const string PipeName = "LanMouseShare.Service";
        public const int DefaultTimeoutMs = 750;
        public const int InputTimeoutMs = 120;
        public const int StatusTimeoutMs = 500;
    }
}
