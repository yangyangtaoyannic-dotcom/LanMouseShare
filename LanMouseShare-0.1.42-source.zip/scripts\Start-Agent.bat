@echo off
setlocal

set "ROOT=%~dp0.."
start "" "%ROOT%\Agent\LanMouseShare.Agent.exe"
